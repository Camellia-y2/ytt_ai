import { useTitle } from '@/hooks/useTitle'
const Account = () => {
    useTitle('我的')
    return (
        <div>
            <h1>Account</h1>
        </div>
    )
}
export default Account